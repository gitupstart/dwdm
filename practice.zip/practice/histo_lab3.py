import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("merged_dataset.csv")  # Change filename as needed

# Choose a numeric attribute for visualization
attribute = "income"  # Change to any numeric column

# Check if the attribute exists
if attribute not in df.columns:
    print(f"Column '{attribute}' not found in the dataset.")
else:
    # Plot histogram
    plt.figure(figsize=(8, 5))
    plt.hist(df[attribute], bins=20, edgecolor='black', alpha=0.7)
    plt.xlabel(attribute.capitalize())
    plt.ylabel("Frequency")
    plt.title(f"Histogram of {attribute.capitalize()}")
    plt.grid(axis="y", linestyle="--", alpha=0.7)

    # Show plot
    plt.show()

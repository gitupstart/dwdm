import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder, StandardScaler
# Load dataset (Replace with actual dataset path)
df = pd.read_csv("merged_dataset.csv")
# Drop unique identifiers if present
df = df.drop(columns=["email", "address", "contact_number"], errors="ignore")
# Convert categorical data to numerical using Label Encoding
nominal_cols = ["state", "name", "country", "date_of_birth", "occupation"]
for col in nominal_cols:
    if col in df.columns:
        df[col] = LabelEncoder().fit_transform(df[col])
# Normalize numerical features (for better clustering performance)
scaler = StandardScaler()
df_scaled = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
# Apply K-Means Clustering
k = 3  # Number of clusters
kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
df_scaled["Cluster"] = kmeans.fit_predict(df_scaled)
# Print cluster counts
print(df_scaled["Cluster"].value_counts())
# Visualize Clusters (using first two features)
plt.scatter(df_scaled.iloc[:, 0], df_scaled.iloc[:, 1], c=df_scaled["Cluster"], cmap="viridis")
plt.xlabel(df.columns[0])
plt.ylabel(df.columns[1])
plt.title("K-Means Clustering Visualization")
plt.colorbar(label="Cluster")
plt.show()
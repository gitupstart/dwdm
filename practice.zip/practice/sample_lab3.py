import pandas as pd

# Load dataset
df = pd.read_csv("merged_dataset.csv")  # Change filename as needed

# Choose an attribute for sampling
attribute = "income"  # Change to any numeric or categorical column

# Number of samples to extract
sample_size = 10  # Change as needed

# Perform random sampling
sampled_data = df[[attribute]].sample(n=sample_size, random_state=42)

# Display sampled data
print("Sampled Data:")
print(sampled_data)

import pandas as pd
from sklearn.model_selection import train_test_split
# Load dataset
df = pd.read_csv("merged_dataset.csv")  # Change filename as needed
# Choose attribute for stratified sampling
stratify_col = "state"  # Change as needed
# Remove categories with less than 2 occurrences
df_filtered = df.groupby(stratify_col).filter(lambda x: len(x) > 1)
# Perform stratified sampling (20% of each group)
if len(df_filtered) > 0:
    stratified_sample, _ = train_test_split(df_filtered, test_size=0.8, stratify=df_filtered[stratify_col], random_state=42)
    # Save the stratified sample
    stratified_sample.to_csv("stratified_sample.csv", index=False)
    print(f"Stratified sample saved as 'stratified_sample.csv'.")
else:
    print("Not enough data for stratified sampling after filtering.")

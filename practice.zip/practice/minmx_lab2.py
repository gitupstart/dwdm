import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Load dataset
df = pd.read_csv("merged_dataset.csv")  # Change filename as needed

# Choose attribute for normalization
attribute = "income"  # Change to any numeric column in your dataset

# Check if the column exists
if attribute not in df.columns:
    print(f"Column '{attribute}' not found in the dataset.")
else:
    # Reshape data for MinMaxScaler
    scaler = MinMaxScaler()
    df[attribute + "_normalized"] = scaler.fit_transform(df[[attribute]])

    # Save the normalized dataset
    df.to_csv("normalized_dataset.csv", index=False)
    
    print(f"Min-Max Normalization applied to '{attribute}' and saved as 'normalized_dataset.csv'.")

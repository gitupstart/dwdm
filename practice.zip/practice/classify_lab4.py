import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Load dataset
df = pd.read_csv("merged_dataset.csv")  # Ensure dataset file is correct

# Drop unique identifiers (not useful for classification)
df = df.drop(columns=["email", "address", "contact_number"])

# Convert income into categories (low, medium, high) for classification
df["income"] = pd.qcut(df["income"], q=3, labels=["Low", "Medium", "High"])

# Encode categorical attributes
nominal_cols = ["state", "name", "country", "date_of_birth", "occupation"]
for col in nominal_cols:
    df[col] = LabelEncoder().fit_transform(df[col])

# Define features and target
X = df.drop(columns=["income"])  # Features
y = df["income"]  # Target (Categorized income)

# Split dataset with stratified sampling
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

# Train Decision Tree model
model = DecisionTreeClassifier(max_depth=5, random_state=42)  # Limit depth to avoid overfitting
model.fit(X_train, y_train)

# Predict & evaluate
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.2f}")

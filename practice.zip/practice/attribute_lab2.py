import pandas as pd

# Load dataset
df = pd.read_csv("merged_dataset.csv")  # Change filename as needed

# Identify attribute types
nominal_attributes = []
ordinal_attributes = []
numeric_attributes = []

# Define ordinal attribute values (example)
ordinal_mappings = {
    "education_level": ["High School", "Bachelor's", "Master's", "PhD"],
    "customer_satisfaction": ["Poor", "Average", "Good", "Very Good", "Excellent"]
}

# Identify attribute types
for column in df.columns:
    if df[column].dtype == "object":  # Categorical
        unique_values = df[column].nunique()
        
        if column in ordinal_mappings:  # Check if predefined ordinal
            ordinal_attributes.append(column)
        elif unique_values < 20:  # Assuming small unique values might be categorical
            nominal_attributes.append(column)
        else:
            nominal_attributes.append(column)
    else:
        numeric_attributes.append(column)  # Numeric data

# Print categorized attributes
print("Nominal Attributes:", nominal_attributes)
print("Ordinal Attributes:", ordinal_attributes)
print("Numeric Attributes:", numeric_attributes)
